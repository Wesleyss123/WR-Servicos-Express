WR Serviços — Site pronto
=========================

Arquivos neste pacote:
- index.html
- css/styles.css
- assets/logo.svg

Como usar:
1. Descompacte o arquivo ZIP.
2. Abra o arquivo `index.html` no navegador para ver o site localmente.
3. Para publicar online:
   - GitHub Pages: crie um repositório e faça upload dos arquivos (index.html na raiz).
   - Netlify: arraste a pasta descompactada para https://app.netlify.com/drop
4. Para editar:
   - Abra css/styles.css para alterar cores e layout.
   - Substitua assets/logo.svg pela sua logo (mesmo nome) se quiser.
   - Se quiser que eu publique por você (GitHub Pages/Netlify), me passe acesso ou confirme e eu te guio.

Contato que já está no site:
- Nome: WR Serviços – Facilitando sua vida
- WhatsApp: +55 (62) 99513-8554
- E-mail: Wesleyrobles2022@hotmail.com
- Área de atendimento: No momento, Goiânia e região metropolitana

Observações:
- O botão/formulário abre o WhatsApp com mensagem pré-preenchida.
- Se quiser integração por e-mail (formularios), posso configurar com Formspree/Netlify Forms.
